function [Cost,dCostdTheta,RMSE,wRegPen] ...
    = computeBatchCost(Theta,inList,outTargList,actFun,wRegFun,wRegWeight,noiseStdv)

[outList]=ffFuncNet(Theta,inList,actFun,noiseStdv);

RMSE=sqrt(mean((outList-outTargList).^2,"all")+1e-8);
if wRegWeight
    wRegPen=wRegFun(Theta);
else
    wRegPen=0;
end

Cost=RMSE + wRegWeight*wRegPen;
dCostdTheta=dlgradient(Cost,Theta);


end