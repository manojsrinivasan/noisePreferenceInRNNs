function [truthVal] = structAnyIsNan(X)


for elem=1:length(X) % loop hrough all elements in struct array
    fns=fieldnames(X(elem));
    for k=1:length(fns)% loop hrough feild names
        name=fns{k};
        if isstruct(X(elem).(name)) % if the field is a struct, recure
            truthVal = structAnyIsNan(X(elem).(name));
        else % 
            truthVal =any(~isfinite(X(elem).(name)),"all");
        end
        if truthVal
            break;
        end
    end
    if truthVal
        break;
    end
end
    


end