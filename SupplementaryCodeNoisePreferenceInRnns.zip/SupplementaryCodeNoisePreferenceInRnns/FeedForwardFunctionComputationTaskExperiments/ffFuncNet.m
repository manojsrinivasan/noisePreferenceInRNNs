function [outList] = ffFuncNet(Theta,inList,actFun,noiseStdv)

numLayers=length(Theta);
hList=inList;
for lay=1:numLayers
    hList=pagemtimes(Theta(lay).W,hList) + Theta(lay).B;
    if lay<numLayers % no actfun or noise for output layer
        hList=actFun(hList+noiseStdv.*randn(size(hList)));% inside noise
    end
    
end
outList=hList;

end