function [M] = structExpMoveMean(M,m,weight,mExp)


for elem=1:length(M) % loop hrough all elements in struct array
    fns=fieldnames(M(elem));
    for k=1:length(fns)% loop hrough feild names
        name=fns{k};
        if isstruct(M(elem).(name)) % if he field is a struct, recure
            M(elem).(name) = structExpMoveMean(M(elem).(name),m(elem).(name),weight,mExp);
        else % update the moving average
            if mExp==1 % standard moving avergae
                M(elem).(name) = weight*M(elem).(name)+(1-weight)*m(elem).(name);
            else % non standard (as for rms prop)
                M(elem).(name) = weight*M(elem).(name)+(1-weight)*(m(elem).(name)).^mExp;
            end             
        end
    end
end
    


end