function [Penalty] = weightDecayPen(Theta)
Penalty=0;
numelTot=0;
for lay=1:length(Theta)
    Penalty=Penalty+sum(Theta(lay).W.^2,'all');
    numelTot=numelTot+numel(Theta(lay).W);
end


Penalty=Penalty/numelTot;
end