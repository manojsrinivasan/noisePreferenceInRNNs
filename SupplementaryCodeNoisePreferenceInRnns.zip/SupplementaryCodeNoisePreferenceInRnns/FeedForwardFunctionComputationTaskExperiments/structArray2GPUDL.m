function [X] = structArray2GPUDL(X)


for elem=1:length(X) % loop hrough all elements in struct array
    fns=fieldnames(X(elem));
    for k=1:length(fns)% loop hrough feild names
        name=fns{k};
        if isstruct(X(elem).(name)) % if the field is a struct, recure
            X(elem).(name) = structArray2GPUDL(X(elem).(name));
        else % make into dl array on gpu
            X(elem).(name) = dlarray(gpuArray(X(elem).(name)));
        end
    end
end
    


end