clc;clear;close all;
saveFigs=0;

load("sin_nStdv1en1_iter2e4_hdim100.mat")
Theta=structExtractdata(bestPerfTheta);



%% make data to test on
numreps=300;
numInSamps=20;

inList=linspace(0,2*pi,numInSamps);
outTargetList=funcToApprox(inList);
inListRepped=repmat(inList,[1 1 1 numreps]);





%% pick a range of noizes to test
numNoiseLevels=20;
neurNoiseList=linspace(0,noiseStdv*1.5,numNoiseLevels)';
neurNoiseList=sort([neurNoiseList;noiseStdv]);

%% get neural and output trajectories
meanVarList=zeros(numNoiseLevels,1);
meanBiasSqrList=meanVarList;
inSpecVarList=zeros(numInSamps,numNoiseLevels);
inSpecBiasSqrList=inSpecVarList;
for k=1:numNoiseLevels+1
    neurNoiseNow=neurNoiseList(k);
    [out] = ffFuncNet(Theta,inListRepped,actFun,neurNoiseNow);
    inSpecVar=var(out,[],4);
    inSpecBiasSqr=(outTargetList-mean(out,4)).^2;
    meanVarList(k)=mean(inSpecVar);
    meanBiasSqrList(k,1)=mean(inSpecBiasSqr);
    inSpecVarList(:,k)=inSpecVar;
    inSpecBiasSqrList(:,k)=inSpecBiasSqr;
end

MSEList=meanBiasSqrList+meanVarList;
%%
figTitle='sinFeedForward';
figFileName='sinFeedForward_stdv1en1_iter2e4_hdim100';

figure()
plot(neurNoiseList,[sqrt(MSEList) sqrt(meanBiasSqrList) sqrt(meanVarList)]);hold on;
xline(noiseStdv);
xlabel('noise standard deviation')
title(figTitle);
if saveFigs
    saveas(gcf,figFileName);
    saveas(gcf,[figFileName '.svg']);
end
