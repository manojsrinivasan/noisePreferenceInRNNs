function [Theta] = adamUpdate(Theta,momVec,rmsVec,stepSz,epsilon)


for elem=1:length(Theta) % loop hrough all elements in struct array
    fns=fieldnames(Theta(elem));
    for k=1:length(fns)% loop through feild names
        name=fns{k};
        if isstruct(Theta(elem).(name)) % if he field is a struct, recure
            Theta(elem).(name) = adamUpdate(Theta(elem).(name),momVec(elem).(name),rmsVec(elem).(name),stepSz,epsilon);
        else % do an adam update on this field
            Theta(elem).(name) = Theta(elem).(name)-stepSz*momVec(elem).(name)./(sqrt(rmsVec(elem).(name))+epsilon);            
        end
    end
end
    


end