function [X] = structZerosLike(X)


for elem=1:length(X) % loop hrough all elements in struct array
    fns=fieldnames(X(elem));
    for k=1:length(fns)% loop hrough feild names
        name=fns{k};
        if isstruct(X(elem).(name)) % if he field is a struct, recure
            X(elem).(name) = structZerosLike(X(elem).(name));
        else % make zeros
            X(elem).(name) = zeros(size(X(elem).(name)),'like',X(elem).(name));
        end
    end
end
    


end