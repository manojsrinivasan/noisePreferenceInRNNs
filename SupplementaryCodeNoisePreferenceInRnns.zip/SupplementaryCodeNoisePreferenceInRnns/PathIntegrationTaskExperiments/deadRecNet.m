function [hnext] = deadRecNet(h,u,Win,Wrec,Bin,actFun,gamma,NeuralNoiseStd)

hnext = h*(1-gamma)+gamma*actFun(pagemtimes(Wrec,h)+pagemtimes(Win,u)+Bin+ ... % recurrence on neural state + dependence on input
   NeuralNoiseStd.*randn(size(h),"like",h)); % neural noise

end