function [zList,hList] = getNeuralAndOutputTrajectories(Theta,uList,zTargetList, ...
    actFun,gamma,NeuralNoiseStd)


%% getting the dimensions of things
hDim=size(Theta,1); 
[uDim,batchSz,numSteps]=size(uList);
zDim = size(zTargetList,1);


%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,Wout,Bout,h0] = unpackTheta(Theta,hDim,uDim,zDim);

%% simulate the network
% initialize h, which is the neural state
h = h0;% all positive initialization
if nargout>1
    hList=zeros([hDim,batchSz,numSteps,size(NeuralNoiseStd,[4 5])]);
end
zList=zeros([zDim,batchSz,numSteps,size(NeuralNoiseStd,[4 5])]);

% get h trajectory (neural trajectory)
for iStep=1:numSteps
    u=uList(:,:,iStep);
    h = ...
        deadRecNet(h,u,Win,Wrec,Bin, ...
        actFun,gamma,NeuralNoiseStd); % recurrent neural network
    z=pagemtimes(Wout,h)+Bout;
    if nargout>1
        hList(:,:,iStep)=h;
    end
    zList(:,:,iStep,:,:)=z;

    
end

end