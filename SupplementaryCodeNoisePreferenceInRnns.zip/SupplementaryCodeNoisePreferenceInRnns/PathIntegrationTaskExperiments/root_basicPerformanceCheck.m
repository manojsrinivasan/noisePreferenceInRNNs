clc;clear;close all;

load("squareRoomL25en1_1e2steps_dsMu1en1_dsStdv1en2_dheadStdv20_actReg0_wReg0_nStdv1en1_stepSz1en3_HL5e3_iter1e4.mat")
Theta=extractdata(Theta);
figure()
plot(RMSEList)

%% make test data
numSteps=numSteps;
numTest=1;
[zTargetList,uList] = trainBatchGen_unicycle_cartOut_headIn_square(numTest,numSteps,dsMu,dsStdv,dheadStdv,roomL);
%[zTargetList,uList] = trainBatchGen_unicycle_cartOut_headIn_square_ds0frac(numTest,numSteps,dsMu,dsStdv,dheadStdv,roomL,ds0frac);

% % as in ceuva & wei, set some random portion of the speed inputs to
%     % zero
%     uList(1,rand(1,numTest,numSteps)<.9)=0;
%% get net outputs
[zList] = getNeuralAndOutputTrajectories(Theta,uList,zTargetList, ...
    actFun,gamma,NeuralNoiseStd);

%% ploting

xTargetPlot=permute(zTargetList,[3 2 1]);
xEstPlot=permute(zList,[3 2 1]);
figure()
C=colororder;
colororder(C(1:numTest,:));
plot(xEstPlot(:,:,1),xEstPlot(:,:,2),'.');hold on;
plot(xTargetPlot(:,:,1),xTargetPlot(:,:,2));

axis equal