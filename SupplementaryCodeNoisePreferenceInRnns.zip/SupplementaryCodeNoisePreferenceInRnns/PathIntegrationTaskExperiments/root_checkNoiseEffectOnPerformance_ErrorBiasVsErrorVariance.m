clc;clear;close all;
saveFig=1;% set to 1 to save the plot
% load in data
load('squareRoomL25en1_1e2steps_dsMu1en1_dsStdv1en2_dheadStdv20_actReg0_wReg0_nStdv1en1_stepSz1en3_HL5e3_iter1e4.mat');
Theta=extractdata(bestPerfTheta);
numReps=100;
batchSz=100;
gamma=gpuArray(gamma);
Theta=gpuArray(Theta);

%% pick a range of noises to test
numNoiseLevels=15;
neurNoiseList=gpuArray(linspace(0,1.5*NeuralNoiseStd,numNoiseLevels-1));
neurNoiseList=sort([neurNoiseList NeuralNoiseStd]);
neurNoiseListRepped=repmat(permute(neurNoiseList,[1 5 3 4 2]),[1 1 1 numReps 1]); % 4th dim = montecarlo repetitions, 5th dim = test noise levels
neurNoiseListRepped=gpuArray(neurNoiseListRepped);
%% get neural and output trajectories

tic;

[zTargetList,uList] = ...
    trainBatchGen_unicycle_cartOut_headIn_square(batchSz,numSteps,dsMu,dsStdv,...
    dheadStdv,roomL);
zTargetList=gpuArray(zTargetList);
uList=gpuArray(uList);
[zList] = ...
    getNeuralAndOutputTrajectories(Theta,uList,zTargetList, ...
    actFun,gamma,neurNoiseListRepped);
meanVarList=sum(var(zList,[],4),[1 2 3])/batchSz/numSteps;
meanBiasSqrList=sum((zTargetList-mean(zList,4)).^2,[1 2 3])/batchSz/numSteps;

meanBiasSqrList=permute(meanBiasSqrList,[5 1 2 3 4]);
meanVarList=permute(meanVarList,[5 1 2 3 4]);
MSEList=meanBiasSqrList+meanVarList;
runTimeTest=toc;
%%
figure()
plot(neurNoiseList,[sqrt(MSEList) sqrt(meanBiasSqrList) sqrt(meanVarList)]);
hold on;
xline(NeuralNoiseStd,'k');
%legend('RMSE','biasRMSEComp','varRMSEComp','training noise level')
xlabel('noise standard deviation'); 
figFileName='errorBiasandVarianceForDeadRecNet10kbatches';
if saveFig
    saveas(gcf,figFileName);
    saveas(gcf,figFileName,'svg');
end