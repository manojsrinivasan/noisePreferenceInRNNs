function [zTargetList,uList,dxList,xList] = trainBatchGen_unicycle_cartOut_headIn_square(batchSz,numSteps,dsMu,dsStdv,dheadStdv,roomL)
%% manoj says: maybe worth doing perturbations off of more sructured walks like radial-out or spirals 

dheadList=dheadStdv*randn(1,batchSz,numSteps);% stepwize changes in heading angle
head0=rand(1,batchSz)*2*pi;
headList=cumsum(dheadList,3)+head0;% heading angle
headListLagged=cat(3,head0,headList(:,:,1:end-1));% lagging headings by one step 
dsList=dsStdv*randn(1,batchSz,numSteps)+dsMu;% stepwize changes in s, the path length
dsList=dsList.*sign(dsList);% always going forward
dxList=[cos(headListLagged);sin(headListLagged)].*dsList;
xList=cumsum(dxList,3);% 2D position 

%% constrain x to be in the box
for step=round(.85*roomL/dsMu/2):numSteps
    % % correct vertical wall collisions
    wallInds=abs(xList(1,:,step))>roomL/2;
    if any(wallInds)
        xReflected=2*xList(1,wallInds,step-1)-xList(1,wallInds,step:end);
        xList(1,wallInds,step:end)=xReflected;
    end
    % % correct horizonal wall collisions;
    wallInds=abs(xList(2,:,step))>roomL/2;
    if any(wallInds)
        xReflected=2*xList(2,wallInds,step-1)-xList(2,wallInds,step:end);
        xList(2,wallInds,step:end)=xReflected;
    end
end
% get correct headings
dxList=diff(xList,1,3);
dxList=cat(3,xList(:,:,1),dxList);
headList=atan2(dxList(2,:,:),dxList(1,:,:));



zTargetList=xList;
uList=[dsList;headList];

end