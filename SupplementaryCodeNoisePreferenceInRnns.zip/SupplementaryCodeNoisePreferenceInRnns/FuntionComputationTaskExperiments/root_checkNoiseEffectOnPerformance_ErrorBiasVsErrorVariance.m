clc;clear;close all;
saveFigs=0;
readOutTypeList=['detRO';'intRO'];
readOutTypeListForTitle={', fixed readout time',', random readout time'};
for readOutTypeNum=1:2
    readOutType=readOutTypeList(readOutTypeNum,:);
    folderName=['savedFuncNetMatFiles_' readOutType];
    dataFolderStruct=dir([folderName '\*.mat']);
    numNets=length(dataFolderStruct);
    for netNum=1:numNets
        MatFileName=dataFolderStruct(netNum).name;
        load([folderName '\' MatFileName]);

        Theta=extractdata(Theta);

        %% plot cost history

        figure()
        plot(batchCostList)

        %% make data to test on
        numreps=300;
        numInSamps=20;

        % identify what kind of network this is
        funcString=func2str(funcToApprox);
        if isequal(funcString(5),'t')
            aproxFunName='tanh';
            inList=linspace(-4,4,numInSamps);
        else
            aproxFunName='sin';
            inList=linspace(0,2*pi,numInSamps);
        end

        if isequal(MatFileName(13),'I')
            noiseType='noiseIn';
            netFun=@FuncNet_noiseIn;
        else
            noiseType='noiseOut';
            netFun=@FuncNet_noiseOut;
        end

        outTargetList=funcToApprox(inList);
        inListRepped=repmat(inList,[1 1 1 numreps]);





        %% pick a range of noizes to test
        if exist('maxNeuralNoiseStd','var')
            NeuralNoiseStd=maxNeuralNoiseStd;
        end
        numNoiseLevels=20;
        neurNoiseList=linspace(0,NeuralNoiseStd*1.5,numNoiseLevels)';
        neurNoiseList=sort([neurNoiseList;NeuralNoiseStd]);

        %% get neural and output trajectories
        meanVarList=zeros(numNoiseLevels,1);
        meanBiasSqrList=meanVarList;
        inSpecVarList=zeros(numInSamps,numNoiseLevels);
        inSpecBiasSqrList=inSpecVarList;
        for k=1:numNoiseLevels+1
            neurNoiseNow=neurNoiseList(k);
            [hList,outList,out] = ...
                GetNeuralAndOutputTrajectories_wNoise(Theta,inListRepped,numSteps, ...
                actFun,gamma,neurNoiseNow,netFun);
            inSpecVar=var(out,[],4);
            inSpecBiasSqr=(outTargetList-mean(out,4)).^2;
            meanVarList(k)=mean(inSpecVar);
            meanBiasSqrList(k,1)=mean(inSpecBiasSqr);
            inSpecVarList(:,k)=inSpecVar;
            inSpecBiasSqrList(:,k)=inSpecBiasSqr;
            if k==1
                finhNoNoise=hList(:,:,end,1);
            end
        end

        MSEList=meanBiasSqrList+meanVarList;
        %%
        figTitle=[aproxFunName readOutTypeListForTitle{readOutTypeNum}];
        figFileName=[aproxFunName '_' noiseType '_' readOutType];

        figure()
        plot(neurNoiseList,[sqrt(MSEList) sqrt(meanBiasSqrList) sqrt(meanVarList)]);hold on;
        xline(NeuralNoiseStd);
        xlabel('noise standard deviation')
        title(figTitle);
        if saveFigs
            saveas(gcf,figFileName);
            saveas(gcf,[figFileName '.svg']);
        end
    end
end