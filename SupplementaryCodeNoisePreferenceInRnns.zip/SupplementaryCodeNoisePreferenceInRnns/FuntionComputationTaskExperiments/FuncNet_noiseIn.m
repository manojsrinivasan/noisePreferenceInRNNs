function [hnext] = FuncNet_noiseIn(h,in,Win,Wrec,Bin,actFun,gamma,NeuralNoiseStd)

hnext = h*(1-gamma)+gamma*actFun(pagemtimes(Wrec,h)+pagemtimes(Win,in)+Bin+ ... % recurrence on neural state + dependence on input
   NeuralNoiseStd.*randn(size(h))); % neural noise

end