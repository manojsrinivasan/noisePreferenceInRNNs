function [Cost,dCostdh,dhMags] = fixedPtCost(Theta,h,in,gamma,actFun,netFun)
%% getting the dimensions of things
hDim=size(Theta,1); 
inDim=size(in,1);


%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,~,~,~] = unpackTheta(Theta,hDim,inDim,1);


%% get cost
dh = ...
    netFun(h,in,Win,Wrec,Bin,actFun,gamma,0)-h;
dhMagsSqr=sum(dh.^2);
Cost=sum(dhMagsSqr);
dhMags=sqrt(dhMagsSqr); 

%% get gradients

dCostdh=dlgradient(Cost,h);

end