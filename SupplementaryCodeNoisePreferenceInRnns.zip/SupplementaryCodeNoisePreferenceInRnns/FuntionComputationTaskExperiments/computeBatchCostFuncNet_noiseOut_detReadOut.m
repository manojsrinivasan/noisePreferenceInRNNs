function [Cost,dCostdTheta,RMSE,svPenalty] = ...
    computeBatchCostFuncNet_noiseOut_detReadOut(Theta,inList,outTargetList,numSteps, ...
    actFun,gamma,NeuralNoiseStd,svRegWeight)
% all readouts happen at the end, and the noise is added inside of the
% activation func
%% getting the dimensions of things
hDim=size(Theta,1); 
[inDim,batchSz]=size(inList);
numSteps=numSteps-1;
outDim = size(outTargetList,1);


%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,Wout,Bout,h0] = unpackTheta(Theta,hDim,inDim,outDim);

%% simulate the network
% initialize h, which is the neural state
h = h0;  
svPenalty=0;

% get h trajectory (neural trajectory)
for iStep=1:numSteps

    h = ...
        FuncNet_noiseOut(h,inList,Win,Wrec,Bin, ...
        actFun,gamma,NeuralNoiseStd); % recurrent neural network
end

out=Wout*h+Bout;

%% calculate cost and gradient
% get RMSE (performance cost)
MSE=sum((out-outTargetList).^2)/batchSz/outDim;
RMSE=sqrt(MSE+1e-8);
% get max SV penalty
if svRegWeight
  Wcat= [Wrec Win];  
  [U,~,V]=svds(extractdata(Wcat),1);
  svPenalty=(U'*Wcat*V)^2;
end


% combine all penalties to get the overall cost
Cost = RMSE + svRegWeight*svPenalty;



dCostdTheta=dlgradient(Cost,Theta);

end