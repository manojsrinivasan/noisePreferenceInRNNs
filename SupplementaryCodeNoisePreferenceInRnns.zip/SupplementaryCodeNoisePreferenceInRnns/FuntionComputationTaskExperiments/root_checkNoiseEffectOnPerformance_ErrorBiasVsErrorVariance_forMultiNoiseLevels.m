clc;clear;close all;
saveFigs=0;
MatFileName='simple_noiseIn_detRO_funcsin_stepSz1en3_stepSzHL25e2_MultnStdv_batchSz32_numSteps100_hDim100_1e4batches.mat';
load(MatFileName);
numNets=size(Theta,3);
Thetas=extractdata(Theta);
figure()
axes("XScale","log","YScale","log");
hold on;
colors=colororder();
colororder(colors(1:3,:));
for netNum=1:numNets
    Theta=Thetas(:,:,netNum);
    NeuralNoiseStd=NeuralNoiseStdList(netNum);
    %% plot cost history

    % figure()
    % plot(batchCostList)

    %% make data to test on
    numreps=300;
    numInSamps=20;

    % identify what kind of network this is
    funcString=func2str(funcToApprox);
    if isequal(funcString(5),'t')
        aproxFunName='tanh';
        inList=linspace(-4,4,numInSamps);
    else
        aproxFunName='sin';
        inList=linspace(0,2*pi,numInSamps);
    end

    if isequal(MatFileName(13),'I')
        noiseType='noiseIn';
        netFun=@FuncNet_noiseIn;
    else
        noiseType='noiseOut';
        netFun=@FuncNet_noiseOut;
    end

    outTargetList=funcToApprox(inList);
    inListRepped=repmat(inList,[1 1 1 numreps]);





    %% pick a range of noizes to test
    if exist('maxNeuralNoiseStd','var')
        NeuralNoiseStd=maxNeuralNoiseStd;
    end
    numNoiseLevels=20;
    neurNoiseList=linspace(0,NeuralNoiseStd*1.5,numNoiseLevels)';
    neurNoiseList=sort([neurNoiseList;NeuralNoiseStd]);

    %% get neural and output trajectories
    meanVarList=zeros(numNoiseLevels,1);
    meanBiasSqrList=meanVarList;
    inSpecVarList=zeros(numInSamps,numNoiseLevels);
    inSpecBiasSqrList=inSpecVarList;
    for k=1:numNoiseLevels+1
        neurNoiseNow=neurNoiseList(k);
        [hList,outList,out] = ...
            GetNeuralAndOutputTrajectories_wNoise(Theta,inListRepped,numSteps, ...
            actFun,gamma,neurNoiseNow,netFun);
        inSpecVar=var(out,[],4);
        inSpecBiasSqr=(outTargetList-mean(out,4)).^2;
        meanVarList(k)=mean(inSpecVar);
        meanBiasSqrList(k,1)=mean(inSpecBiasSqr);
        inSpecVarList(:,k)=inSpecVar;
        inSpecBiasSqrList(:,k)=inSpecBiasSqr;
        if k==1
            finhNoNoise=hList(:,:,end,1);
        end
    end

    MSEList=meanBiasSqrList+meanVarList;
    %%
    
    
    plot(neurNoiseList,[sqrt(MSEList) sqrt(meanBiasSqrList) sqrt(meanVarList)]);
    xline(NeuralNoiseStd);
    drawnow;
    
end
figFileName=[aproxFunName '_' noiseType '_NoiseLevsAllTogether_loglog'];
figTitle=[aproxFunName ' detReadout, noiseStdv=' num2str(NeuralNoiseStd)];
xlabel('noise standard deviation')
%title(figTitle);
if saveFigs
    saveas(gcf,figFileName);
    saveas(gcf,[figFileName '.svg']);
end