function [hList,outList,out] = ...
    GetNeuralAndOutputTrajectories_wNoise(Theta,inList,numSteps, ...
    actFun,gamma,NeuralNoiseStd,netFun)


%% getting the dimensions of things
hDim=size(Theta,1); 
[inDim,batchSz,~,numReps]=size(inList);
numSteps=numSteps-1;
outDim=1;


%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,Wout,Bout,h0] = unpackTheta(Theta,hDim,inDim,outDim);



%% simulate the network
% initialize h, which is the neural state
h = h0;  
hList=zeros(hDim,batchSz,numSteps,numReps);

% get h trajectory (neural trajectory)
for iStep=1:numSteps

    h = ...
        netFun(h,inList,Win,Wrec,Bin, ...
        actFun,gamma,NeuralNoiseStd); % recurrent neural network
    hList(:,:,iStep,:)=h;
end

outList=pagemtimes(Wout,h)+Bout;
out=outList(:,:,end,:);
end