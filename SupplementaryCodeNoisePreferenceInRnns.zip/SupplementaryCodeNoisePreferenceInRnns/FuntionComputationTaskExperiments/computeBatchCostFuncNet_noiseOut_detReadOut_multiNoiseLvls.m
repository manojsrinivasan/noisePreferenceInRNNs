function [Cost,dCostdTheta,RMSE,svPenalty] = ...
    computeBatchCostFuncNet_noiseOut_detReadOut_multiNoiseLvls(ThetaList,inList,outTargetList,numSteps, ...
    actFun,gamma,NeuralNoiseStdList,svRegWeight)
% all readouts happen at the end, and the noise is added inside of the
% activation func
%% getting the dimensions of things
hDim=size(ThetaList,1); 
[inDim,batchSz]=size(inList);
numSteps=numSteps-1;
outDim = size(outTargetList,1);

%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,Wout,Bout,h0] = unpackTheta(ThetaList,hDim,inDim,outDim);

%% simulate the network
% initialize h, which is the neural state
h = h0;  
svPenalty=0;

% get h trajectory (neural trajectory)
for iStep=1:numSteps

    h = ...
        FuncNet_noiseOut(h,inList,Win,Wrec,Bin, ...
        actFun,gamma,NeuralNoiseStdList); % recurrent neural network
end

out=pagemtimes(Wout,h)+Bout;

%% calculate cost and gradient
% get RMSE (performance cost)
MSE=sum((out-outTargetList).^2,2)/batchSz/outDim;
RMSE=sum(sqrt(MSE+1e-8));
% get max SV penalty
if svRegWeight
  Wcat= [Wrec Win];  
  [U,~,V]=pagesvd(extractdata(Wcat),"econ");
  Utrans=pagetranspose(U(:,1,:)); V=V(:,1,:);
  svPenalty=sum(pagemtimes(pagemtimes(Utrans,Wcat),V).^2);
end


% combine all penalties to get the overall cost
Cost = RMSE + svRegWeight*svPenalty;



dCostdTheta=dlgradient(Cost,ThetaList);

end