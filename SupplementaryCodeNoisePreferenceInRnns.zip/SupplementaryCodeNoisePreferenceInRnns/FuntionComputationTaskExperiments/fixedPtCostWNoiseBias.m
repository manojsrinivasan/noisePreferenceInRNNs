function [Cost,dCostdh,dhMags] = fixedPtCostWNoiseBias(Theta,h,in,gamma,actFun,netFun,numNoiseSamps,preferedNoiseStd)
%% getting the dimensions of things
hDim=size(Theta,1); 
inDim=size(in,1);

%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,~,~,~] = unpackTheta(Theta,hDim,inDim,1);


%% get cost
hRepped=h.*ones(1,1,numNoiseSamps);
hn=netFun(hRepped,in,Win,Wrec,Bin,actFun,gamma,preferedNoiseStd);
dh = mean(hn,3)-h;
dhMagsSqr=sum(dh.^2);
Cost=sum(dhMagsSqr);
dhMags=sqrt(dhMagsSqr); 

%% get gradients

dCostdh=dlgradient(Cost,h);

end