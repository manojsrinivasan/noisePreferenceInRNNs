function [Win,Wrec,Bin,Wout,Bout,h0] = unpackTheta(Theta,hDim,inDim,outDim)

% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
Wrec = Theta(:,1:hDim,:); % matrix that multiplies neural state for recurrent dynamics
Win = Theta(:,hDim+1:hDim+inDim,:); % matrix that multiplies the input
Bin = Theta(:,hDim+inDim+1,:); % bias term for recurrent dynamics
Wout = pagetranspose(Theta(:,hDim+inDim+2:hDim+inDim+1+outDim,:)); % matrix that multiplies neural state for output
Bout = Theta(:,hDim+inDim+2+outDim,:);  % bias term for for output 
Bout = Bout(1:outDim,:,:); % we use only as many dims as in task space and ignore the rest of the entires
h0=Theta(:,end,:);

end