function [zList] = getOutputTrajectories(Theta,uList,actFun,gamma,NeuralNoiseStd)

hDim=size(Theta,1); [uDim,batchSz,numSteps]=size(uList);

%% unpacking
Wrec=Theta(:,1:hDim); Win=Theta(:,hDim+1:hDim+uDim); Bin=Theta(:,hDim+uDim+1);
Wout=Theta(:,hDim+uDim+2:end-1)'; Bout=Theta(1:3,end);

zDim=length(Bout);
%% simulate the network
% initialize h (driscoll didnt mention how they did this, so im going with zero)
h=zeros(hDim,batchSz);
zList=zeros([zDim batchSz numSteps size(NeuralNoiseStd,[4 5])]);
% get h trajectory
for k=1:numSteps
    u=uList(:,:,k);
    h = cogNet(h,u,Win,Wrec,Bin,actFun,gamma,NeuralNoiseStd);
    z = pagemtimes(Wout,h)+Bout;
    zList(:,:,k,:,:)=z;
end











end