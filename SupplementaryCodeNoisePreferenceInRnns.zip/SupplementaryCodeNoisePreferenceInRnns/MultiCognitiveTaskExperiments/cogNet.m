function [hnext] = cogNet(h,u,Win,Wrec,Bin,actFun,gamma,NeuralNoiseStd)

hnext=h*(1-gamma)+gamma*actFun(pagemtimes(Wrec,h)+pagemtimes(Win,u)+Bin...
    +NeuralNoiseStd.*randn(size(h)));

end