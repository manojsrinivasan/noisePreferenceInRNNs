function [hList,zList] = ...
    GetNeuralAndOutputTrajectories_wNoise_repped(Theta,uList,fixationList,actFun,deltaT,gamma,ziList,TPindicatorList,neuralNoiseStd,numReps)


%% getting the dimensions of things
hDim=size(Theta,1); 
[uDim,batchSz,numSteps]=size(uList);
numSteps=numSteps-1;
zDim = size(ziList,1);
fixDim=size(fixationList,1);

%% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
[Win,Wrec,Bin,Wfeedback,Wfixation,Wout,Bout,h0] = unpackTheta(Theta,hDim,uDim,zDim,fixDim);
startPtNums=TPindicatorList(2,:,1);
h0=actFun(h0(:,startPtNums));% make sure starting activations are positive




%% simulate the network
% initialize h, which is the neural state
h = repmat(h0,[1 1 1 numReps]);
hList=h;
z = repmat(ziList,[1 1 1 numReps]); % initial state for position 
zList=z;
% get h trajectory (neural trajectory)
for iStep=1:numSteps
    u = uList(:,:,iStep); % input now, for the k-th timestep
    fixationNow = fixationList(:,:,iStep);
    h = ...
        TmazeNet(h,u,z,fixationNow,Win,Wrec,Bin,Wfeedback,Wfixation, ...
        actFun,gamma,neuralNoiseStd); % recurrent neural network
    hList=cat(3,hList,h);

    % get output from neural state
    z = z+(pagemtimes(Wout,h) + Bout)*deltaT; 
    zList=cat(3,zList,z); % just concatenating to the current zList
end

end