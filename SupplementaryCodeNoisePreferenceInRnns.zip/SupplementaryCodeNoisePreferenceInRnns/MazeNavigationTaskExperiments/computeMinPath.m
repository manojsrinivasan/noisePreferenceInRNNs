function optPath = computeMinPath(iPoint,jPoint,majorPaths)

% majorPaths = [majorPaths; majorPaths(:,end:-1:1)];

temp1 = (majorPaths==iPoint);
temp2 = (majorPaths==jPoint);
temp3 = temp1+temp2;

colSum = sum(temp3,2);
iBestRow = min(find(colSum==2));
% bestRow = majorPaths(iBestRow,:);

iCol = find(temp1(iBestRow,:));
jCol = find(temp2(iBestRow,:));
if iCol<=jCol
    optPath = majorPaths(iBestRow,iCol:jCol);
else
    optPath = majorPaths(iBestRow,iCol:-1:jCol);
end

% pause

end