function [zDemoList, ruleList, fixList, TPindicatorList] = ...
    trainBatchGen_randPauseBuffer(batchSz,optPathPt2Pt,pMatrix,...
    downTimeNumSteps,pauseNumStepsRng,startNumStepsRng,...
    jauntNumSteps,totalNumSteps)

% the TP indicator for a particular time step during a jaunt in a particular trial
% goes [roueStartPoint#; jauntStartPoint#; jauntEndPoint#; routeEndPoint#; isEnd].
% for times when we're not jaunting, it goes [roueStartPoint#; currentPoint#; 0; routeEndPoint#; isEnd]
% for down time, its just [0; currentPoint#; 0; 0; 0]
% the isEnd disambiguates if were on the end pause or
% the start pause for routes that stay at 1 point


% make a convex combo matrix for doing 2D smoothsep for building zDemo
smthStep=linspace(0,1,jauntNumSteps+1);
smthStep=smthStep(1:end-1);
smthStep=3*smthStep.^2-2*smthStep.^3;
convComboMat=[1-smthStep;smthStep];

numPtsTotal=length(pMatrix);% total number of poins in the graph
% inititializing things
ruleList=ones(2,batchSz,totalNumSteps-downTimeNumSteps);
zDemoList=zeros(2,batchSz,totalNumSteps-downTimeNumSteps);
fixList=zeros(2,batchSz,totalNumSteps-downTimeNumSteps);
TPindicatorList=zeros(5,batchSz,totalNumSteps-downTimeNumSteps);


for trl=1:batchSz
    iPoint=randi(numPtsTotal);
    jPoint=randi(numPtsTotal);
    % make rule input
    ruleList(:,trl,:)=ruleList(:,trl,:).*pMatrix(jPoint,:)';
    % make everything else
    pIndSeq=optPathPt2Pt{iPoint,jPoint};
    pSeqNow=pMatrix(pIndSeq,:)';% 2xn array of points
    numPts=size(pSeqNow,2);% number of points along this path
    numJaunts=numPts-1;% number of jaunts along this path (a jaunt is a move from one point to he next)
    % set up list of pause lengths so as not to make any one pause
    % longer all the time
    pauseNumStepsList=[randi(startNumStepsRng) randi(pauseNumStepsRng,[1 numJaunts])];
    extraPauseNumSteps=totalNumSteps-sum(pauseNumStepsList)-jauntNumSteps*numJaunts-downTimeNumSteps;
    bufferPause=randi(numPts);
    pauseNumStepsList(bufferPause)=pauseNumStepsList(bufferPause)+extraPauseNumSteps;
    startFixNumSteps=pauseNumStepsList(1);% number of starting fixation steps
    zDemo=repmat(pSeqNow(:,1),[1 1 startFixNumSteps]);
    fixation=repmat([1;0],[1 1 startFixNumSteps]);%


    TPindicator=repmat([iPoint; iPoint; 0; jPoint;0 ],[1 1 startFixNumSteps]);

    for jaunt=1:numJaunts
        %figure out if we're in a final jaunt
        isEnd=jaunt==numJaunts;
        % tack the next jaunt+pause onto zDemo
        jauntTraj=pSeqNow(:,jaunt:jaunt+1)*convComboMat;
        jauntTraj=permute(jauntTraj,[1 3 2]);
        zDemo=cat(3,zDemo,jauntTraj);
        pauseNumSteps=pauseNumStepsList(jaunt+1);
        pauseTraj=repmat(pSeqNow(:,jaunt+1),[1 1 pauseNumSteps]);
        zDemo=cat(3,zDemo,pauseTraj);
        % tack the next jaunt+pause onto fixation
        jauntFix=zeros(2,1,jauntNumSteps);
        pauseFix=repmat([0;1],[1 1 pauseNumSteps]);
        fixation=cat(3,fixation,jauntFix,pauseFix);
        % tack the next jaunt+pause onto the task period indicator
        jauntID=pIndSeq(jaunt:jaunt+1)';
        jauntTPindicator=repmat([iPoint;jauntID;jPoint;0],[1 1 jauntNumSteps]);
        pauseTPindicator=repmat([iPoint; jauntID(2); 0; jPoint; isEnd],[1 1 pauseNumSteps]);
        TPindicator=cat(3,TPindicator,jauntTPindicator,pauseTPindicator);
    end
    zDemoList(:,trl,:)=zDemo;
    fixList(:,trl,:)=fixation;
    TPindicatorList(:,trl,:)=TPindicator;
end


%% stick a down time block on the front all the trials

downFixList=repmat(fixList(:,:,end),[1 1 downTimeNumSteps]);
downTPindList=zeros([size(TPindicatorList,[1 2]) downTimeNumSteps]);
downTPindList(2,:,:)=repmat(TPindicatorList(2,:,1),[1 1 downTimeNumSteps]);
downRuleList=repmat(zDemoList(:,:,1),[1 1 downTimeNumSteps]);% as if we just finished a roue ending on the starting point of the curren trial
downZdemoList=downRuleList;


fixList=cat(3,downFixList,fixList);
TPindicatorList=cat(3,downTPindList,TPindicatorList);
ruleList=cat(3,downRuleList,ruleList);
zDemoList=cat(3,downZdemoList,zDemoList);







end