function [hnext] = TmazeNet(h,u,z,fixationNow,Win,Wrec,Bin,Wfeedback,Wfixation,actFun,gamma,NeuralNoiseStd)

hnext = h*(1-gamma)+gamma*actFun(pagemtimes(Wrec,h)+Win*u+Bin+ ... % recurrence on neural state + dependence on rule input
    pagemtimes(Wfeedback,z) + Wfixation*fixationNow + ... % feedback on state and fixation. feedback is assumed perfect, but wlog neural noise accounts for state feedback uncertainty
    NeuralNoiseStd*randn(size(h))); % neural noise

end