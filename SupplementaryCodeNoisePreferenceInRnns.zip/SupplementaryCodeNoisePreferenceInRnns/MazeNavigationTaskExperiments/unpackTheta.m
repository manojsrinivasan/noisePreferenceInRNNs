function [Win,Wrec,Bin,Wfeedback,Wfixation,Wout,Bout,h0] = unpackTheta(Theta,hDim,uDim,zDim,fixDim)

% unpacking theta=[Wrec Win Bin Wout' Bout Wfeedback Wfixation h0]
Wrec = Theta(:,1:hDim); % matrix that multiplies neural state for recurrent dynamics
Win = Theta(:,hDim+1:hDim+uDim); % matrix that multiplies rule input for recurrent dynamics
Bin = Theta(:,hDim+uDim+1); % bias term for recurrent dynamics
Wout = Theta(:,hDim+uDim+2:hDim+uDim+1+zDim)'; % matrix that multiplies neural state for output
Bout = Theta(:,hDim+uDim+2+zDim);  % bias term for for output 
Bout = Bout(1:zDim,:); % we use only as many dims as in task space (2D) and ignore the rest of the entires, which are redundant
Wfeedback = Theta(:,hDim+uDim+3+zDim:hDim+uDim+2+2*zDim);
Wfixation = Theta(:,hDim+uDim+3+2*zDim:hDim+uDim+2+2*zDim+fixDim); 
h0=Theta(:,hDim+uDim+3+2*zDim+fixDim:end);

end