clc;close all; clear;
numMuS=1001;
maxMuS=3;
maxNoiseStdv=2;
numNoiseLevels=5;
numNoiseSamps=1e5;
noiseStdvs=permute(linspace(0,maxNoiseStdv,numNoiseLevels),[1 3 2]);
noiseSampList=randn(numNoiseSamps,numMuS,numNoiseLevels).*noiseStdvs;
muSList=linspace(-maxMuS,maxMuS,numMuS);
actFun=@(x) x.*(x>0);

excitationSampList=actFun(muSList+noiseSampList);
meanExcitationList=mean(excitationSampList);

%% plotting
muSList=muSList';
meanExcitationList=permute(meanExcitationList,[2 3 1]);
lgnd=[repmat('sigma = ',[numNoiseLevels 1]) num2str(noiseStdvs(:))];
cmap=cool(numNoiseLevels);
colororder(cmap);
plot(muSList,meanExcitationList);
legend(lgnd);
ylim([-.5 3.5])






