
clear; close all; clc;
thetaLarge=.2; thetaSmall=.1;
numSteps=1000000;
noiseLevels=linspace(0,1);
x=0;
statDistribMeans=zeros(size(noiseLevels));
for iStep=1:numSteps
    x=x.*(1-(thetaLarge*(x<0)+thetaSmall*(x>0)) )+noiseLevels.*randn(size(noiseLevels));
    statDistribMeans=(statDistribMeans*(iStep-1)+x)/iStep;
end

plot(noiseLevels,statDistribMeans)
ylabel('stationary distribution bias estimate')
xlabel('injected noise standard deviation')