clc;clear;close all;

ReLU=@(x) x.*(x>0);
SatReLU=@(x) sign(x).*min(abs(x),1);
Sigmoid=@(x) 1./(1+exp(-x));
doubleAct=@(x) [SatReLU(x+5);Sigmoid(x+4)];

gamma=.2;
w=-4;

h=linspace(-2,4,601);

hdot=gamma*(-h+doubleAct(w*h))';
plot(h,hdot); hold on;
yline(0)
legend('sat relu','sig')

